#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <set>

using namespace std;

// Structure to hold patient information
struct Patient {
    int id;
    string fullName;
    int age;
    string gender;
    string address;
    string contactNumber;
    string emergencyContact;
    string status; // "In Treatment" or "Completed"
    string date; // history
    string room_number;
    string treatment_type;
};

// Service charges for departments (General Medicine, Surgery, Orthopedics, Pediatrics)
int serviceCharges[] = {200, 500, 400, 150};

// Global filename variable for selected department
string filename;

// Function prototypes
void selectDepartment();
void registerPatient();
void viewAllPatients();
void searchPatientByID();
void editPatientInfo();
void migratePatient();
void billingMenu();
int getNextID();
string assign_room();
string appointmentDate(); // Gets the date for appointment

// Function to get the preferred date
string appointmentDate() {
    int day, month, year;
    string date;
    bool validDate = false;
    while (!validDate) {
        a:
        cout << "Enter preferred date (day month year): ";
        cin >> day >> month >> year;
        // Simple date validation (no leap year check)
        if (month < 1 || month > 12 || day < 1 || day > 31 || year < 25) {
            cout << "Invalid date. Please try again.\n";
        } else {
            validDate = true;
            date = to_string(day) + "-" + to_string(month) + "-" + to_string(year);
            ifstream file(filename);
            if(!file){
                return date;
                }
            else{
            string line;
                int count = 0;
                while (getline(file, line)) {
                    stringstream ss(line);
                    string id,fullname,age,gender,address,contactNumber,emergencyContact,status,appointmentDate;
                    getline(ss, id, ',');
                    getline(ss, fullname, ',');
                    getline(ss, age, ',');
                    getline(ss, gender, ',');
                    getline(ss, address, ',');
                    getline(ss, contactNumber, ','); 
                    getline(ss, emergencyContact, ',');
                    getline(ss, status, ',');
                    getline(ss, appointmentDate, ','); 

                    if (appointmentDate == date) {
                        count++;
                    }
        }
        if (count >= 1) {
            cout << "Cannot register! The date is fully booked. Enter another date: " << endl;
            goto a;
        }else{return date;}
                              }
        }
    }

}













// Select department inside each function
void selectDepartment() {
    int departmentChoice = 0;
    cout << "Select Department:\n";
    cout << "1. General Medicine\n";
    cout << "2. Surgery\n";
    cout << "3. Orthopedics\n";
    cout << "4. Pediatrics\n";
    cout << "Enter your choice: ";
    cin >> departmentChoice;

    switch (departmentChoice) {
        case 1: filename = "general_medicine.csv"; break;
        case 2: filename = "surgery.csv"; break;
        case 3: filename = "orthopedics.csv"; break;
        case 4: filename = "pediatrics.csv"; break;
        default:
            cout << "Invalid choice. Defaulting to General Medicine.\n";
            filename = "general_medicine.csv";
    }
}













// Registers a new patient
void registerPatient() {
    selectDepartment();  // Ask for department before registration

    Patient p;
    p.id = getNextID();
    int room;

    cout << "Enter full name: ";
    cin.ignore();
    getline(cin, p.fullName);
    cout << "Enter age: ";
    cin >> p.age;
    cin.ignore();
    cout << "Enter gender: ";
    getline(cin, p.gender);
    cout << "Enter address: ";
    getline(cin, p.address);
    cout << "Enter contact number: ";
    getline(cin, p.contactNumber);
    cout << "Enter emergency contact: ";
    getline(cin, p.emergencyContact);
    cout <<"IF ROOM IS NEEDED ENTER 1:"<<endl;
    cin>>room;
    if(room==1){
         p.room_number= assign_room();}
         else {p.room_number="NO ROOM RESERVED";}
    p.status = "In Treatment"; // Default status
    p.date = appointmentDate();


    ofstream file(filename, ios::app); // Append to file
    if (file.is_open()) {
        file << p.id << "," << p.fullName << "," << p.age << "," << p.gender << ","
             << p.address << "," << p.contactNumber << "," << p.emergencyContact << ","
             << p.status << "," << p.date <<"," <<p.room_number<< "\n";

        file.close();
        cout << "Patient registered successfully with ID: " << p.id << endl;
    } else {
        cout << "Error opening file.\n";
    }
}


void migratePatient() {
    selectDepartment();
    string sourceFile = filename;

    string id;
    cout << "Enter patient ID to migrate: ";
    cin.ignore();
    getline(cin, id);

    ifstream file(sourceFile);
    ofstream temp("temp.csv");
    string line;
    bool found = false;
    string patientLine;

    //  Find and remove from current file
    while (getline(file, line)) {
        stringstream ss(line);
        string field;
        getline(ss, field, ',');
        if (field == id) {
            found = true;
            patientLine = line;
            continue; // skip writing this patient to temp.csv (effectively deleting it)
        }
        temp << line << "\n";
    }
    file.close();
    temp.close();
    remove(sourceFile.c_str());
    rename("temp.csv", sourceFile.c_str());

    if (!found) {
        cout << "Patient with ID " << id << " not found.\n";
        return;
    }

    //  Ask for target department
    cout << "Select target department to migrate to:\n";
    string targetFile;
    selectDepartment();
    targetFile = filename;

    //  Update filename and append to new file
    ofstream target(targetFile, ios::app);
    if (target.is_open()) {
        target << patientLine << "\n";
        stringstream ss(patientLine);
        string field, lastField;

        while (getline(ss, field, ',')) {
            lastField = field;
        }
        lastField = assign_room();

        target.close();
        cout << "Patient migrated successfully to " << targetFile << ".\n";
    } else {
        cout << "Error opening target file.\n";
    }
}
























// Registers a new patient
string assign_room() {
    set<int> occupiedRooms;

    int start, end;
    if (filename == "general_medicine.csv") {
        start = 1; end = 99;
    } else if (filename == "surgery.csv") {
        start = 100; end = 199;
    } else if (filename == "orthopedics.csv") {
        start = 200; end = 299;
    } else if (filename == "pediatrics.csv") {
        start = 300; end = 399;
    }

    ifstream file(filename);
    if(file.is_open()){
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string field, lastField;

            while (getline(ss, field, ',')) {
                lastField = field;
            }

            if (lastField != "NO ROOM RESERVED" && lastField != "")  {
                occupiedRooms.insert(stoi(lastField));
            }
        }
        file.close();

        // Find first available room
        for (int room = start; room <= end; room++) {
        if(occupiedRooms.find(room) == occupiedRooms.end()) {
                return to_string(room);
            }
        }

        cout << "All rooms are reserved" << endl;
        return "NO ROOM RESERVED";
    }
        
    else{


        cout<<"File was not opened successfully for reading rooms"<<endl;
    
    
    
    }
}











// Generates the next patient ID by counting existing entries
int getNextID() {
    ifstream file(filename);
    string line;
    int count = 0;
    while (getline(file, line)) {
        count++;
    }
    file.close();
    return count + 1;
}












// Displays all patients in the department
void viewAllPatients() {
    selectDepartment();  // Ask for department before viewing patients

    ifstream file(filename);
    if (!file.is_open()) {   // check if file opened successfully
        cout << "No records found or error opening file.\n";
        return;
    }

    string line;

    cout << "\n--- List of Patients ---\n";
    cout << left << setw(5) << "ID"
         << setw(20) << "Full Name"
         << setw(5) << "Age"
         << setw(10) << "Gender"
         << setw(20) << "Address"
         << setw(20) << "Contact No"
         << setw(20) << "Emergency No"
         << setw(20) << "Status"
         << setw(12) << "Date"
         << setw(15) << "Room No"<< endl;

    cout << string(160, '-') << endl; // separator line

    while (getline(file, line)) {
        stringstream ss(line);
        string item;
        int column = 0;

        while (getline(ss, item, ',')) {
            switch (column) {
                case 0: cout << left << setw(5) << item; break;
                case 1: cout << left << setw(20) << item; break;
                case 2: cout << left << setw(5) << item; break;
                case 3: cout << left << setw(10) << item; break;
                case 4: cout << left << setw(20) << item; break;
                case 5: cout << left << setw(20) << item; break;
                case 6: cout << left << setw(20) << item; break;
                case 7: cout << left << setw(20) << item; break;
                case 8: cout << left << setw(12) << item; break;
                case 9: cout << left << setw(15) << item; break;
                default: cout << item << " "; break;
            }
            column++;
        }
        cout << endl;
    }
    file.close();
}














// Searches for a patient by their ID
void searchPatientByID() {
    selectDepartment();  // Ask for department before searching

    string id;
    cout << "Enter patient ID to search: ";
    cin.ignore();
    getline(cin, id);

    ifstream file(filename);
    string line;
    bool found = false;

    while (getline(file, line)) {
        stringstream ss(line);
        string field;
        getline(ss, field, ',');
        if (field == id) {
            found = true;
            cout << "\n--- Patient Found ---\n";
            cout << "ID: " << field << endl;

            string labels[] = {"Full Name", "Age", "GENDER", "Address", "Contact Number",
                "EMERGENCY CONTACT", "Status", "Appointment DATE","ROOM_NUMBER"};
                for (int i = 0; i < 9; i++) {
                    getline(ss, field, ',');
                    if (field.empty()) {
                        field = "N/A";

                    }
                    cout << labels[i] << ": " << field << endl;
                }
                if (filename == "general_medicine.csv") {
            cout << "department:GENERAL_MEDICINE" << endl;

        }
        if (filename == "surgery.csv" ) {
            cout << "department:SURGERY" << endl;

        }
        if (filename == "orthopedics.csv" ) {
            cout << "department:ORTHOPEDICS" << endl;

        }
        if (filename == "pediatrics.csv") {
            cout << "department:PEDIATRICS" << endl;

        }
            break;
        }
    }
    if (found == false) {
        cout << "Patient with ID " << id << " not found.\n";
    }
    file.close();
}


















// Edits patient information by ID
void editPatientInfo() {
    selectDepartment();
    string id, output, line, newValue;
    int choice;
    bool found = false;

    cin.ignore();
    cout << "Enter patient ID to edit: ";
    getline (cin, id);

    cout << "Enter choice of attribute to edit:\n";
    cout << "1. Full Name\n" << "2. Age\n" << "3. Gender\n" << "4. Address\n" << "5. Contact Number\n";
    cout << "6. Emergency Contact\n" << "7. Status\n" << "8. Appointment date\n" << "9. Room Number\n";

    cout << "Enter your choice: ";
    cin >> choice;

    cin.ignore();
    cout << "Enter new value: ";
    getline(cin, newValue);

    ifstream file(filename);
    ofstream temp("temp.csv");

    while (getline(file, line)) {
        stringstream ss(line);
        string field;
        getline(ss, field, ',');
        string currentID = field;
        output = currentID;

        if (currentID == id) {
            found = true;
            int fieldCount = 0;
            while (getline(ss, field, ',')) {
                fieldCount++;
                output += ",";
                if (fieldCount == choice) {
                    output += newValue;
                } else {
                    output += field;
                }
            }
            temp << output << "\n";
        }
        else {
            temp << line << "\n";
        }
    }

    file.close();
    temp.close();
    remove(filename.c_str());
    rename("temp.csv", filename.c_str());

    if (found) {
        cout << "Patient information updated successfully.\n";
    } else {
        cout << "Patient with ID " << id << " not found.\n";
    }
    cout << endl;

}



















void billingMenu() {
    selectDepartment();  // Ask for department before billing

    int id, days = 0;
    cout << "Enter patient ID for billing: ";
    cin >> id;

    // Check if the patient exists in the file
    ifstream file(filename);
    string line;
    bool found = false;
    ofstream temp("temp.csv");

    while (getline(file, line)) {
        stringstream ss(line);
        string Patient_id;
        getline(ss, Patient_id, ',');
        int currentID = stoi(Patient_id);

        if (currentID == id) {
            found = true;
            string room;
            string status="Complete";

            for (int i = 1; getline(ss, room, ','); i++) {
                if (i == 9) {
                    if (room=="NO ROOM RESERVED") {
                        days=0;
                    }else{
                        cout<<"Enter number of days stayed: ";
                        cin>>days;
                     }
                } 
            }
            

            // Calculate the bill (service charge + room charge based on days)
            int departmentIndex = filename == "general_medicine.csv" ? 0 :
                                  filename == "surgery.csv" ? 1 :
                                  filename == "orthopedics.csv" ? 2 : 3;
            int totalBill = serviceCharges[departmentIndex] + (days * 100);  // Assuming 100/day for room

            cout << "Total Bill: $" << totalBill << endl;

            // Update status to "Completed" and write patient info to temp
            temp << currentID << ",";
            stringstream ss2(line);
            string status_update;
            getline(ss2, status_update, ',');

            for (int i = 1; getline(ss2, status_update, ','); i++) {
                
                if(i==9){
                     temp<<"NO ROOM RESERVED";

                }
                
                else if (i == 7) {
                    temp << "Completed,"; // Update status to "Completed"
                } else {
                    temp << status_update << ",";
                }
            }
            temp << "\n";
        } else {
            temp << line << "\n"; // Copy other patient records
        }
    }

    file.close();
    temp.close();

    if (found) {
        remove(filename.c_str());
        rename("temp.csv", filename.c_str());
        cout << "Patient status updated to 'Completed' and billing finalized.\n";
    } else {
        cout << "Patient with ID " << id << " not found.\n";
    }
}




















// Main function - Display the menu
int main() {
    int choice;
    do {
        cout << "\n--- Main Menu ---\n";
        cout << "1. Register new patient\n";
        cout << "2. Search for a patient by ID\n";
        cout << "3. Edit patient information\n";
        cout << "4. View all patients\n";
        cout << "5. Billing\n";
        cout << "6. Migrate Patient\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); // Clear input buffer

        switch (choice) {
            case 1: registerPatient(); break;
            case 2: searchPatientByID(); break;
            case 3: editPatientInfo(); break;
            case 4: viewAllPatients(); break;
            case 5: billingMenu(); break;
            case 6: migratePatient(); break;;
            case 7: cout << "Exiting program.\n"; break;
            default: cout << "Invalid option. Try again.\n";
        }
    } while (choice != 7);

    return 0;
}

