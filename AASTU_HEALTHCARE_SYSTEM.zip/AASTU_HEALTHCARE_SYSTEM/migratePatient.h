#pragma once
#include <iostream>
#include "selectdepartment.h"
#include "assign_room.h"
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <set>

using namespace std;
void migratePatient(string filename) {
    selectDepartment(filename);
    string sourceFile = filename;

    string id;
    cout << "Enter patient ID to migrate: ";
    cin.ignore();
    getline(cin, id);

    ifstream file(sourceFile);
    ofstream temp("temp.csv");
    string line;
    bool found = false;
    string patientLine;

    //  Find and remove from current file
    while (getline(file, line)) {
        stringstream ss(line);
        string field;
        getline(ss, field, ',');
        if (field == id) {
            found = true;
            patientLine = line;
            continue; // skip writing this patient to temp.csv (effectively deleting it)
        }
        temp << line << "\n";
    }
    file.close();
    temp.close();
    remove(sourceFile.c_str());
    rename("temp.csv", sourceFile.c_str());

    if (!found) {
        cout << "Patient with ID " << id << " not found.\n";
        return;
    }

    //  Ask for target department
    cout << "Select target department to migrate to:\n";
    string targetFile;
    selectDepartment(filename);
    targetFile = filename;

    //  Update filename and append to new file
    ofstream target(targetFile, ios::app);
    if (target.is_open()) {
        target << patientLine << "\n";
        stringstream ss(patientLine);
        string field, lastField;

        while (getline(ss, field, ',')) {
            lastField = field;
        }
        lastField = assign_room(filename);

        target.close();
        cout << "Patient migrated successfully to " << targetFile << ".\n";
    } else {
        cout << "Error opening target file.\n";
    }
}
