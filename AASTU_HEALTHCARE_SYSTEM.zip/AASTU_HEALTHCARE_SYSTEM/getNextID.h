#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

int getNextID(string filename) {
    ifstream file(filename);
    string line;
    int count = 0;
    while (getline(file, line)) {
        count++;
    }
    file.close();
    return count + 1;
}